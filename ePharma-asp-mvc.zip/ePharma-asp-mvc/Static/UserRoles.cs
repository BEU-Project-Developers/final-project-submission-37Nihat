﻿namespace ePharma_asp_mvc.Static
{
    public static class UserRoles
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
