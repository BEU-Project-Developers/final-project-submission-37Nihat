﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ePharma_asp_mvc.Migrations
{
    public partial class AddMigration2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
